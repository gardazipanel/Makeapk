package com.apkmaker.shell;
import android.Manifest;
import android.app.Activity;
import android.app.DownloadManager;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ActivityInfo;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.view.WindowManager;
import android.webkit.*;
import android.widget.Toast;
import org.json.JSONObject;
import java.io.InputStream;
import java.util.ArrayList;

public class MainActivity extends Activity {
 WebView w;ValueCallback<Uri[]> fcb;static final int FC=77;
 @Override protected void onCreate(Bundle b){
  super.onCreate(b);
  String url="file:///android_asset/www/index.html";JSONObject o=new JSONObject();
  try{InputStream is=getAssets().open("config.json");byte[] x=new byte[is.available()];is.read(x);is.close();o=new JSONObject(new String(x,"UTF-8"));
   if(o.optString("url").length()>0)url=o.getString("url");}catch(Exception e){}
  String perms=o.optString("perms");
  if(o.optBoolean("fullscreen"))getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);
  if(o.optBoolean("awake"))getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
  if("portrait".equals(o.optString("orient")))setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
  // Permissions sirf pehli dafa poochhi jati hain
  SharedPreferences sp=getSharedPreferences("p",0);
  if(!sp.getBoolean("asked",false)){
   sp.edit().putBoolean("asked",true).apply();
   ArrayList<String> l=new ArrayList<>();
   if(perms.contains("camera"))l.add(Manifest.permission.CAMERA);
   if(perms.contains("mic"))l.add(Manifest.permission.RECORD_AUDIO);
   if(perms.contains("location"))l.add(Manifest.permission.ACCESS_FINE_LOCATION);
   if(perms.contains("storage")){l.add(Manifest.permission.READ_EXTERNAL_STORAGE);l.add(Manifest.permission.WRITE_EXTERNAL_STORAGE);}
   if(perms.contains("contacts"))l.add(Manifest.permission.READ_CONTACTS);
   if(perms.contains("phone"))l.add(Manifest.permission.CALL_PHONE);
   if(perms.contains("notifications")&&Build.VERSION.SDK_INT>=33)l.add("android.permission.POST_NOTIFICATIONS");
   if(!l.isEmpty())requestPermissions(l.toArray(new String[0]),1);
  }
  w=new WebView(this);setContentView(w);
  WebSettings s=w.getSettings();s.setJavaScriptEnabled(true);s.setDomStorageEnabled(true);s.setDatabaseEnabled(true);
  s.setAllowFileAccess(true);s.setAllowContentAccess(true);s.setGeolocationEnabled(true);
  s.setMediaPlaybackRequiresUserGesture(false);s.setLoadWithOverviewMode(true);s.setUseWideViewPort(true);
  s.setMixedContentMode(WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE);
  w.setWebViewClient(new WebViewClient(){
   @Override public boolean shouldOverrideUrlLoading(WebView v,String u){
    if(u.startsWith("http")||u.startsWith("file:")||u.startsWith("about:")||u.startsWith("data:")||u.startsWith("blob:"))return false;
    try{startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse(u)));}catch(Exception e){}return true;}
   @Override public void onReceivedError(WebView v,int c,String d,String f){
    if(f!=null&&f.startsWith("http"))v.loadData("<h2 style='font-family:sans-serif;text-align:center;margin-top:40%'>Internet nahi hai</h2>","text/html","UTF-8");}
  });
  w.setWebChromeClient(new WebChromeClient(){
   @Override public void onPermissionRequest(final PermissionRequest r){runOnUiThread(new Runnable(){public void run(){r.grant(r.getResources());}});}
   @Override public void onGeolocationPermissionsShowPrompt(String o,GeolocationPermissions.Callback c){c.invoke(o,true,false);}
   // Gallery / files se upload (HTML mein <input type=file>)
   @Override public boolean onShowFileChooser(WebView v,ValueCallback<Uri[]> cb,FileChooserParams p){
    if(fcb!=null)fcb.onReceiveValue(null);fcb=cb;
    try{startActivityForResult(p.createIntent(),FC);}catch(Exception e){fcb=null;return false;}
    return true;}
  });
  w.setDownloadListener((u,ua,cd,mt,len)->{
   try{DownloadManager.Request r=new DownloadManager.Request(Uri.parse(u));r.setMimeType(mt);r.addRequestHeader("User-Agent",ua);
    r.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
    r.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS,URLUtil.guessFileName(u,cd,mt));
    ((DownloadManager)getSystemService(DOWNLOAD_SERVICE)).enqueue(r);Toast.makeText(this,"Download shuru",Toast.LENGTH_SHORT).show();
   }catch(Exception e){try{startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse(u)));}catch(Exception e2){}}
  });
  w.loadUrl(url);
 }
 @Override protected void onActivityResult(int rq,int rs,Intent d){
  super.onActivityResult(rq,rs,d);
  if(rq==FC&&fcb!=null){fcb.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(rs,d));fcb=null;}
 }
 @Override public void onBackPressed(){if(w.canGoBack())w.goBack();else super.onBackPressed();}
}
